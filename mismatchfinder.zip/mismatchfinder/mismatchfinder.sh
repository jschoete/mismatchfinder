for file in input/* ; do
	echo ------------------
    echo Treating file:
    echo $file
    echo ------------------
    java -jar DNA_code.jar $file
done

echo ------------------
echo All files treated.
echo ------------------